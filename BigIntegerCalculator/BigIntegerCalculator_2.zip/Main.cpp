#include <iostream>

#include "Calculator.h"
#include "BigInteger.h"

void main(const int argc, const char* const * const argv)
{
	/*
	BigInteger a("1843245");
	BigInteger b("951423");

	std::cout << a.AsString() << std::endl;
	std::cout << b.AsString() << std::endl;
	std::cout << (a * b).AsString() << std::endl;

	return;
	*/

	Calculator calc;

//	auto result = calc.Calculate("123456789987654321+987654321123456789");
	auto result = calc.Calculate(argv[1]);

	std::cout << result.AsString() << std::endl;
}