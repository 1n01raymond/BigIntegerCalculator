#include "BigInteger.h"

#include <sstream>

BigInteger::BigInteger(const int value)
	:m_Negative(value < 0)
{
	std::stringstream ss;

	if (m_Negative)
		ss << -value;
	else
		ss << value;
	m_Data = ss.str();

	std::reverse(m_Data.begin(), m_Data.end());
}

BigInteger::BigInteger(const std::string value)
	:m_Data(value), m_Negative(value[0] == '-')
{
	if (m_Negative)
		m_Data = m_Data.substr(1);

	std::reverse(m_Data.begin(), m_Data.end());

	TrimZero();
}

const BigInteger operator +(const BigInteger& a, const BigInteger& b)
{
	std::string resultData;
	int carry = 0;
	for (size_t i = 0; i < a.m_Data.length() || i < b.m_Data.length(); ++i)
	{
		int digitA = i < a.m_Data.length() ? a.m_Data[i] - '0' : 0;
		int digitB = i < b.m_Data.length() ? b.m_Data[i] - '0' : 0;

		if (a.m_Negative) digitA = -digitA;
		if (b.m_Negative) digitB = -digitB;

		int digitSum = digitA + digitB + carry;

		// ������ ��� == ������ 10�� �ڸ� + ����� 1�� �ڸ�
		// ex) -7 -> -10 + 3
		// ex) -16 -> -20 + 4
		// ex) -10 -> -10 + 0
		if (digitSum < 0)
		{
			resultData += static_cast<char>((digitSum + 20) % 10 + '0');
			carry = (digitSum - 9) / 10;
		}
		else
		{
			resultData += static_cast<char>(digitSum % 10 + '0');
			carry = digitSum / 10;
		}
	}

	BigInteger result;
	if (carry < 0)
	{
		/*
			ex)
			-20000000
			+ 1234567
			==
			-10000000
			- 9999999
			+ 1234567
			-       1
			9�� ������ ���ϰ� 1�� ���Ѵ�.
			���ϴ� ������, ������ -1�� ���ϱ� ������ �������� ���� ��� + 1
		*/

		result.m_Negative = true;
		for (char& ch : resultData)
			ch = 9 - (ch - '0') + '0';
		resultData += static_cast<char>(-(carry + 1) + '0');
	}
	else if (carry > 0)
	{
		resultData += static_cast<char>(carry + '0');
	}
	result.m_Data = resultData;

	result.TrimZero();

	if (carry < 0)
		result.AddOne();

	return result;
}

const BigInteger operator *(const BigInteger& a, const BigInteger& b)
{
	BigInteger result;
	for (size_t i = 0; i < b.m_Data.length(); ++i)
	{
		if (i > 0)
			result.m_Data = "0" + result.m_Data;

		char ch = b.m_Data[b.m_Data.length() - i - 1];
		if (ch == '0')
			continue;

		BigInteger middleResult = a;
		middleResult.MultiplyOneDigit(ch - '0');

		result = result + middleResult;
	}
	result.m_Negative = a.m_Negative != b.m_Negative;
	return result;
}

const BigInteger operator %(const BigInteger& a, const BigInteger& b)
{
	return a;
}

const BigInteger BigInteger::Power(const BigInteger& other) const
{
	return other;
}

std::string BigInteger::AsString() const
{
	std::string str = m_Data;
	std::reverse(str.begin(), str.end());
	if (m_Negative)
		str = '-' + str;
	return str;
}

void BigInteger::MultiplyOneDigit(const int value)
{
	int carry = 0;
	for (char& ch : m_Data)
	{
		int digit = ch - '0';
		digit = digit * value + carry;
		carry = digit / 10;
		ch = digit % 10 + '0';
	}
	if (carry > 0)
		m_Data += static_cast<char>(carry + '0');
}

void BigInteger::TrimZero()
{
	int realLength = m_Data.length();
	for (; realLength > 1; --realLength)
	{
		if (m_Data[realLength - 1] != '0')
			break;
	}
	m_Data = m_Data.substr(0, realLength);

	if (realLength == 1 && m_Data[0] == '0')
		m_Negative = false;
}

void BigInteger::AddOne()
{
	bool carry = false;
	for (char& ch : m_Data)
	{
		carry = ch == '9';
		ch = (ch - '0' + 1) % 10 + '0';
		if (!carry)
			break;
	}
}
