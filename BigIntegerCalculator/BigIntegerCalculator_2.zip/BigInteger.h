#pragma once

#include <string>

class BigInteger
{
public:
	BigInteger(const int value = 0);
	explicit BigInteger(const std::string value);

	friend const BigInteger operator +(const BigInteger& a, const BigInteger& b);
	friend const BigInteger operator *(const BigInteger& a, const BigInteger& b);
	friend const BigInteger operator %(const BigInteger& a, const BigInteger& b);

	const BigInteger Power(const BigInteger& other) const;

	std::string AsString() const;

	void MultiplyOneDigit(const int value);
private:
	void TrimZero();
	void AddOne();

private:
	// index 0: 1�� �ڸ�, index 1: 10�� �ڸ� ...
	std::string m_Data;
	bool m_Negative;
};