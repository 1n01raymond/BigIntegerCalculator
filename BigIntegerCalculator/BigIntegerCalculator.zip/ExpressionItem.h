#pragma once

struct ExpressionItem
{
	enum ItemType {
		NUMBER
		, OPERATOR
	};

	ExpressionItem()
		:type(NUMBER), data("")
	{}
	ExpressionItem(const ItemType type, const std::string data)
		:type(type), data(data)
	{}
	ExpressionItem(const ExpressionItem& other)
		:type(other.type), data(other.data)
	{}
	ExpressionItem& operator =(const ExpressionItem& other)
	{
		type = other.type;
		data = other.data;
		return *this;
	}

	ItemType type;
	std::string data;

};
