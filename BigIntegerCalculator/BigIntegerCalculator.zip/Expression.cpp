#include "Expression.h"

#include <stack>
#include <string>
#include <cmath>

int Expression::Eval() const
{
	int result = 0;
	std::stack<int> valueStack;

	for (auto& item : m_ItemList)
	{
		if (item.type == ExpressionItem::NUMBER)
		{
			valueStack.push(std::stoi(item.data));
		}
		else
		{
			int rightValue = valueStack.top();
			valueStack.pop();

			int leftValue = valueStack.top();
			valueStack.pop();

			int resultValue;

			if (item.data == "+")
			{
				resultValue = leftValue + rightValue;
			}
			else if (item.data == "*")
			{
				resultValue = leftValue * rightValue;
			}
			else if (item.data == "%")
			{
				resultValue = leftValue % rightValue;
			}
			else if (item.data == "**")
			{
				resultValue = static_cast<int>(std::pow(leftValue, rightValue));
			}
			else
			{
				throw "Unexpected operator. " + item.data;
			}

			valueStack.push(resultValue);
		}
	}

	return valueStack.top();
}

void Expression::Push(const ExpressionItem& item)
{
	m_ItemList.push_back(item);
}
