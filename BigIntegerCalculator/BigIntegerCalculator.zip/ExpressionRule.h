#pragma once

#include <string>

struct ExpressionRule
{
	enum Direction
	{
		RIGHT
		, LEFT
	};

	ExpressionRule()
		:priority(0), direction(RIGHT)
	{}

	ExpressionRule(const std::string& str, const int priority, const Direction direction)
		:str(str), priority(priority), direction(direction)
	{}

	ExpressionRule(const ExpressionRule& other)
		:str(other.str), priority(other.priority), direction(other.direction)
	{}

	ExpressionRule& operator =(const ExpressionRule& other)
	{
		str = other.str;
		priority = other.priority;
		direction = other.direction;
		return *this;
	}

	std::string str;
	int priority;
	Direction direction;
};