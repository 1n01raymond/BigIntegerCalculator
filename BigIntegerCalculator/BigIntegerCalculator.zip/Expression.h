#pragma once

#include <list>

#include "ExpressionItem.h"

class Expression
{
public:
	int Eval() const;

	void Push(const ExpressionItem& item);

private:
	std::list<ExpressionItem> m_ItemList;
};